# Payal3214 GitHub Profile — Setup

## Repository structure

```text
Payal3214/
├── README.md
├── assets/
│   ├── hero.gif
│   ├── decision-engine.gif
│   ├── product-lab.gif
│   └── footer.gif
└── .github/
    └── workflows/
        └── pacman.yml
```

## Install

Copy these files into the root of your profile repository:

- `README.md`
- `assets/`
- `.github/workflows/pacman.yml`

## Pac-Man

The workflow uses `abozanona/pacman-contribution-graph` to generate an animated SVG from the repository owner's real contribution calendar and publishes it to the `output` branch.

If GitHub Actions cannot push the generated SVG, open:

**Repository → Settings → Actions → General → Workflow permissions**

and allow **Read and write permissions**.

Then go to:

**Actions → 🟡 Update Pac-Man Contribution Graph → Run workflow**

After it succeeds, the README will load:

- `output/pacman-contribution-graph.svg`
- `output/pacman-contribution-graph-dark.svg`

## Important

Do not put the Pac-Man workflow inside `README.md`.

The workflow belongs at:

`.github/workflows/pacman.yml`

The README only embeds the generated SVG.

## Custom assets

The four GIFs are self-contained and do not need an external image service:

- `hero.gif` — animated PayalOS hero
- `decision-engine.gif` — animated product decision pipeline
- `product-lab.gif` — animated funnel + RICE dashboard
- `footer.gif` — animated closing visual

They can be replaced later without changing the README layout.
